export default {
    pc: {
        coupon: {
            couponList: {
                couponTab: ['Доступные купоны', 'уже используется', 'просрочен'],
                couponUi: {
                    unit: ['юань', 'уменьшать', 'ломать'],
                    dateTitle: 'срок действия:',
                    couponNone: 'Пока нет ваучеров'
                },

            }
        }
    }
}