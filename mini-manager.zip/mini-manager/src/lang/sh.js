export default {
    pc: {
        coupon: {
            couponList: {
                couponTab: ['可用优惠券', '已使用', '已过期'],
                couponUi: {
                    unit: ['元', '减', '折'],
                    dateTitle: '有效期：',
                    couponNone: '暂无优惠券'
                },

            }
        }
    }
}