export default {
    pc: {
        coupon: {
            couponList: {
                couponTab: ['Available coupon', 'Has been used', 'Expired'],
                couponUi: {
                    unit: ['Yuan', 'Reduce', 'Discount'],
                    dateTitle: 'The period of validity：',
                    couponNone: 'No coupon'
                },

            }
        }
    }
}