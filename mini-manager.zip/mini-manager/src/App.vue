<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: 'app'
}
</script>
<style rel="stylesheet/scss" lang="scss" scoped>
/*  .btn-inner{float: right;width: 78px;height:30px;font-size: 12px;margin: 8px;line-height: 6px;}
  .btn-outer{width:84px;height:38px;font-size: 14px;}
  .btn-del{background-color: rgb(229, 98, 34);}
  .last-table{border-right: 2px solid #eee;}*/
</style>
