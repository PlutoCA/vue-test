
<template>
  <div class="bgwhite">
<v-title>
  <div slot="">编辑新增</div>
</v-title>
    <!-- <div :prop="props"></div> -->
  </div>
</template>

<script>
import Title from "./ui-modules/title/index.vue";
export default {
  components: {
    "v-title": Title
  },
  props: ["", ""],
  data() {
    return {};
  },
  created() {},
  mounted() {},
  methods: {}
};
</script>

<style scoped lang="scss">
</style>