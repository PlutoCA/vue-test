<template>
  <div class="title">
    <solt name=""></solt>
  </div>
</template>
<script>
export default {
  
  data() {
    return {  
    };
  },
};
</script>
<style rel="stylesheet/scss" lang="scss" scoped>
.bgwhite {
 
}
</style>




