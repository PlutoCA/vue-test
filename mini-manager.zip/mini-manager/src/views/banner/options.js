const options = [{
  value: 1,
  label: '小程序首页'
}, {
  value: 2,
  label: '精选页面'
}, {
  value: 3,
  label: '供需页面'
}, {
  value: 4,
  label: '采购流程'
}]
export default options;